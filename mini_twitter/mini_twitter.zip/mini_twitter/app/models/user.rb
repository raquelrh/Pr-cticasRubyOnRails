class User < ApplicationRecord
  has_many :micropost
end
